import React, { useState } from 'react';
import { 
  Users, 
  Crown, 
  Shield, 
  HardHat, 
  Activity, 
  Cpu, 
  Radio, 
  BarChart3, 
  TrendingUp, 
  ChevronRight, 
  Search, 
  Flame, 
  Wind, 
  Droplets, 
  Thermometer, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Battery,
  Wifi,
  Layers,
  ArrowUpDown,
  Volume2,
  Zap,
  Gauge,
  ShieldCheck
} from 'lucide-react';
import { PlatformConfig, SensorDevice, TelemetryHistoryPoint, UserProfile, UserRole } from '../types';

interface InteractiveDeviceChartAndUsersProps {
  currentUser?: UserProfile | null;
  usersList: UserProfile[];
  devices: SensorDevice[];
  activeDeviceId?: string;
  onSelectDevice: (deviceId: string) => void;
  onSelectUser?: (user: UserProfile) => void;
  onChangeUserModal?: () => void;
  activeAlertCount?: number;
  platformConfig?: PlatformConfig;
  telemetryHistory?: TelemetryHistoryPoint[];
  siteName?: string;
}

export const InteractiveDeviceChartAndUsers: React.FC<InteractiveDeviceChartAndUsersProps> = ({
  currentUser,
  usersList,
  devices,
  activeDeviceId,
  onSelectDevice,
  onSelectUser,
  onChangeUserModal,
  activeAlertCount = 0,
  platformConfig,
  telemetryHistory = [],
  siteName,
}) => {
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<'todos' | UserRole>('todos');
  const [chartViewMode, setChartViewMode] = useState<'all_bars' | 'levels' | 'timeline'>('all_bars');
  const [timelineGroup, setTimelineGroup] = useState<'gases' | 'clima' | 'seguridad' | 'todos'>('gases');
  const [hoveredSensorId, setHoveredSensorId] = useState<string | null>(null);

  // Currently selected device for the chart
  const currentDevice = devices.find(d => d.id === activeDeviceId) || devices[0];

  // Helper for current user role theme
  const getRoleDetails = (role?: UserRole) => {
    switch (role) {
      case 'superadmin':
        return {
          label: 'Superadministrador',
          typeText: '(Superadmin)',
          bg: 'bg-purple-950/70 border-purple-600/70 text-purple-300 shadow-purple-950/40',
          badgeBg: 'bg-purple-900/60 border-purple-500/80 text-purple-200',
          avatarBg: 'bg-gradient-to-br from-purple-600 to-indigo-800 text-white border-purple-400',
          icon: <Crown className="w-4 h-4 text-purple-400" />,
          description: 'Control Total de Faena, Parámetros y Auditoría Sernageomin'
        };
      case 'admin':
        return {
          label: 'Administrador / Prevencionista',
          typeText: '(Admin)',
          bg: 'bg-cyan-950/70 border-cyan-600/70 text-cyan-300 shadow-cyan-950/40',
          badgeBg: 'bg-cyan-900/60 border-cyan-500/80 text-cyan-200',
          avatarBg: 'bg-gradient-to-br from-cyan-600 to-blue-800 text-white border-cyan-400',
          icon: <Shield className="w-4 h-4 text-cyan-400" />,
          description: 'Gestión de Alertas, Equipos, Reportes y Operaciones'
        };
      case 'operador':
      default:
        return {
          label: 'Operador de Terreno',
          typeText: '(Operador)',
          bg: 'bg-amber-950/70 border-amber-600/70 text-amber-300 shadow-amber-950/40',
          badgeBg: 'bg-amber-900/60 border-amber-500/80 text-amber-200',
          avatarBg: 'bg-gradient-to-br from-amber-600 to-orange-700 text-white border-amber-400',
          icon: <HardHat className="w-4 h-4 text-amber-400" />,
          description: 'Monitoreo de Variables Atmosféricas y Protocolo de Seguridad'
        };
    }
  };

  const userRoleInfo = getRoleDetails(currentUser?.role);

  // Filter users based on search query and role filter
  const filteredUsers = usersList.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
      (user.rut && user.rut.toLowerCase().includes(userSearchTerm.toLowerCase())) ||
      (user.shift && user.shift.toLowerCase().includes(userSearchTerm.toLowerCase()));
    
    const matchesRole = selectedRoleFilter === 'todos' || user.role === selectedRoleFilter;
    return matchesSearch && matchesRole;
  });

  // Calculate stats for top quick widgets
  const totalUsersCount = usersList.length;
  const superadminCount = usersList.filter(u => u.role === 'superadmin').length;
  const adminCount = usersList.filter(u => u.role === 'admin').length;
  const operadorCount = usersList.filter(u => u.role === 'operador').length;
  const onlineDevicesCount = devices.filter(d => d.status !== 'desconectado').length;

  // Extract real readings for the currently selected device (respecting sensor faultFields)
  const faultSet = new Set(currentDevice?.faultFields || []);
  const coFault = faultSet.has('CO');
  const pmFault = faultSet.has('PM2_5');
  const tempFault = faultSet.has('temperatura');
  const humFault = faultSet.has('humedad');

  const isRawCO = currentDevice?.rawCO !== undefined;
  const isRawPM25 = currentDevice?.rawPM25 !== undefined;
  const coValue = coFault ? 0 : (isRawCO ? currentDevice!.rawCO! : (currentDevice?.metrics?.co ?? 0));
  const pm25Value = pmFault ? 0 : (isRawPM25 ? currentDevice!.rawPM25! : (currentDevice?.metrics?.polvoPM ?? 0));
  const tempValue = tempFault ? 0 : (currentDevice?.rawTemp !== undefined ? currentDevice.rawTemp : (currentDevice?.metrics?.temperatura ?? 0));
  const humValue = humFault ? 0 : (currentDevice?.rawHum !== undefined ? currentDevice.rawHum : (currentDevice?.metrics?.humedad ?? 0));
  const co2Value = currentDevice?.metrics?.co2 ?? 0;
  const airFlowValue = currentDevice?.metrics?.flujoAire ?? 0;
  const ch4Value = currentDevice?.metrics?.ch4 ?? 0;
  const noiseValue = currentDevice?.metrics?.ruido ?? 0;
  const o2Value = currentDevice?.metrics?.o2 ?? 0;
  const batteryPct = currentDevice?.batteryPct ?? 0;

  const pm = platformConfig?.metrics;
  const tempSafe = pm?.tempPreventivo ?? 28;
  const tempCrit = pm?.tempCritico ?? 32;
  const humSafe = pm?.humPreventivo ?? 70;
  const humCrit = pm?.humCritico ?? 85;
  const coSafe = isRawCO ? (pm?.coPreventivo ?? 300) : (pm?.coChartSafeMax ?? 50);
  const coCrit = isRawCO ? (pm?.coCritico ?? 1200) : coSafe * 2;
  const co2Safe = pm?.co2SafeMax ?? 1000;
  const co2Crit = pm?.co2CriticalMax ?? 2000;
  const pm25Safe = isRawPM25 ? (pm?.pm25Preventivo ?? 350) : (pm?.pm25ChartSafeMax ?? 50);
  const pm25Crit = isRawPM25 ? (pm?.pm25Critico ?? 1200) : pm25Safe * 3;
  const ch4Safe = pm?.ch4SafeMax ?? 1.5;
  const ch4Crit = pm?.ch4CriticalMax ?? 5.0;
  const airMin = pm?.airFlowMin ?? 0.5;
  const airMax = pm?.airFlowMax ?? 3.0;
  const noiseSafe = pm?.noiseSafeMax ?? 82;
  const noiseCrit = pm?.noiseCriticalMax ?? 90;
  const o2Min = pm?.o2MinSafe ?? 19.5;

  // Complete list of ALL 9 sensors with precise units, limits, and color themes
  const allSensorBars = [
    {
      id: 'temp',
      name: 'Temperatura',
      shortName: 'Temp',
      unit: '°C',
      value: Number(tempValue.toFixed(1)),
      safeMax: tempSafe,
      criticalMax: tempCrit,
      scaleMax: Math.max(40, tempCrit + 5),
      icon: <Thermometer className="w-4 h-4 text-cyan-400" />,
      gradient: 'from-cyan-500 to-blue-600',
      glowColor: 'shadow-cyan-500/30',
      badgeColor: tempFault ? 'bg-amber-950 text-amber-300 border-amber-700' : tempValue > tempCrit ? 'bg-rose-950 text-rose-300 border-rose-800' : tempValue > tempSafe ? 'bg-amber-950 text-amber-300 border-amber-800' : 'bg-cyan-950 text-cyan-300 border-cyan-800',
      textColor: tempFault ? 'text-amber-400' : tempValue > tempCrit ? 'text-rose-400' : tempValue > tempSafe ? 'text-amber-400' : 'text-cyan-400',
      status: tempFault ? 'FALLA' : tempValue > tempCrit ? 'Calor' : tempValue > tempSafe ? 'Alerta' : 'Óptimo',
      norm: `DS 132: ${pm?.tempMin ?? 18}° - ${tempSafe}°C`
    },
    {
      id: 'hum',
      name: 'Humedad',
      shortName: 'Humedad',
      unit: '%',
      value: Number(humValue.toFixed(1)),
      safeMax: humSafe,
      criticalMax: humCrit,
      scaleMax: 100,
      icon: <Droplets className="w-4 h-4 text-blue-400" />,
      gradient: 'from-blue-500 to-indigo-600',
      glowColor: 'shadow-blue-500/30',
      badgeColor: humFault ? 'bg-amber-950 text-amber-300 border-amber-700' : humValue > humCrit ? 'bg-amber-950 text-amber-300 border-amber-800' : 'bg-blue-950 text-blue-300 border-blue-800',
      textColor: humFault ? 'text-amber-400' : humValue > humCrit ? 'text-amber-400' : 'text-blue-400',
      status: humFault ? 'FALLA' : humValue > humCrit ? 'Elevada' : 'Normal',
      norm: `DS 132: ${pm?.humMin ?? 40}% - ${humSafe}%`
    },
    {
      id: 'co',
      name: isRawCO ? 'Gas MQ-2 (ADC)' : 'Monóxido CO (MQ-2)',
      shortName: 'CO (MQ2)',
      unit: isRawCO ? 'ADC' : 'ppm',
      value: Number(coValue.toFixed(1)),
      safeMax: coSafe,
      criticalMax: coCrit,
      scaleMax: isRawCO ? Math.max(4095, coCrit) : Math.max(100, coCrit),
      icon: <Flame className="w-4 h-4 text-orange-400" />,
      gradient: coValue >= coCrit ? 'from-rose-600 to-red-500' : coValue >= coSafe ? 'from-amber-500 to-orange-500' : 'from-emerald-500 to-teal-500',
      glowColor: coValue >= coCrit ? 'shadow-rose-500/40' : 'shadow-orange-500/30',
      badgeColor: coFault ? 'bg-amber-950 text-amber-300 border-amber-700' : coValue >= coCrit ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse' : coValue >= coSafe ? 'bg-amber-950 text-amber-300 border-amber-800' : 'bg-emerald-950 text-emerald-300 border-emerald-800',
      textColor: coFault ? 'text-amber-400' : coValue >= coCrit ? 'text-rose-400' : coValue >= coSafe ? 'text-amber-400' : 'text-emerald-400',
      status: coFault ? 'FALLA' : coValue >= coCrit ? 'Peligro' : coValue >= coSafe ? 'Alerta' : 'Seguro',
      norm: isRawCO ? `ESP32 ADC · Prev ≤ ${coSafe}` : `DS 132: LPP ≤ ${coSafe} ppm`
    },
    {
      id: 'co2',
      name: 'Dióxido CO2',
      shortName: 'CO2',
      unit: 'ppm',
      value: co2Value,
      safeMax: co2Safe,
      criticalMax: co2Crit,
      scaleMax: Math.max(2000, co2Crit),
      icon: <Wind className="w-4 h-4 text-emerald-400" />,
      gradient: co2Value > co2Crit * 0.75 ? 'from-rose-500 to-red-600' : co2Value > co2Safe ? 'from-amber-500 to-yellow-600' : 'from-emerald-500 to-green-600',
      glowColor: 'shadow-emerald-500/30',
      badgeColor: co2Value > co2Crit * 0.75 ? 'bg-rose-950 text-rose-300 border-rose-800' : co2Value > co2Safe ? 'bg-amber-950 text-amber-300 border-amber-800' : 'bg-emerald-950 text-emerald-300 border-emerald-800',
      textColor: co2Value > co2Crit * 0.75 ? 'text-rose-400' : co2Value > co2Safe ? 'text-amber-400' : 'text-emerald-400',
      status: co2Value > co2Crit * 0.75 ? 'Ventilar' : co2Value > co2Safe ? 'Atención' : 'Seguro',
      norm: `DS 132: LPP ≤ ${co2Safe} ppm`
    },
    {
      id: 'pm25',
      name: isRawPM25 ? 'Polvo PM2.5 (ADC)' : 'Polvo en Suspensión',
      shortName: 'PM2.5',
      unit: isRawPM25 ? 'ADC' : 'µg/m³',
      value: Number(pm25Value.toFixed(1)),
      safeMax: pm25Safe,
      criticalMax: pm25Crit,
      scaleMax: isRawPM25 ? Math.max(4095, pm25Crit) : Math.max(150, pm25Crit),
      icon: <Layers className="w-4 h-4 text-amber-300" />,
      gradient: pm25Value >= pm25Crit ? 'from-rose-500 to-red-600' : pm25Value >= pm25Safe ? 'from-amber-500 to-yellow-500' : 'from-cyan-500 to-teal-500',
      glowColor: 'shadow-amber-500/30',
      badgeColor: pmFault ? 'bg-amber-950 text-amber-300 border-amber-700' : pm25Value >= pm25Crit ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse' : pm25Value >= pm25Safe ? 'bg-amber-950 text-amber-300 border-amber-800' : 'bg-cyan-950 text-cyan-300 border-cyan-800',
      textColor: pmFault ? 'text-amber-400' : pm25Value >= pm25Crit ? 'text-rose-400' : pm25Value >= pm25Safe ? 'text-amber-400' : 'text-cyan-400',
      status: pmFault ? 'FALLA' : pm25Value >= pm25Crit ? 'Crítico' : pm25Value >= pm25Safe ? 'Moderado' : 'Óptimo',
      norm: isRawPM25 ? `ESP32 ADC · Prev ≤ ${pm25Safe}` : `DS 132: LPP ≤ ${pm25Safe} µg/m³`
    },
    {
      id: 'ch4',
      name: 'Gas Metano (CH4)',
      shortName: 'CH4',
      unit: '% LEL',
      value: Number(ch4Value.toFixed(1)),
      safeMax: ch4Safe,
      criticalMax: ch4Crit,
      scaleMax: Math.max(5.0, ch4Crit),
      icon: <Zap className="w-4 h-4 text-purple-400" />,
      gradient: ch4Value > ch4Safe ? 'from-rose-600 to-red-600' : 'from-purple-500 to-pink-500',
      glowColor: 'shadow-purple-500/30',
      badgeColor: ch4Value > ch4Safe ? 'bg-rose-950 text-rose-300 border-rose-800' : 'bg-purple-950 text-purple-300 border-purple-800',
      textColor: ch4Value > ch4Safe ? 'text-rose-400' : 'text-purple-400',
      status: ch4Value > ch4Safe ? 'Crítico' : 'Seguro',
      norm: `DS 132: Máx ${ch4Safe}% LEL`
    },
    {
      id: 'airFlow',
      name: 'Flujo de Ventilación',
      shortName: 'Ventilación',
      unit: 'm/s',
      value: Number(airFlowValue.toFixed(2)),
      safeMax: airMax,
      criticalMax: airMin,
      scaleMax: Math.max(3.0, airMax),
      icon: <Wind className="w-4 h-4 text-teal-400" />,
      gradient: airFlowValue < airMin ? 'from-rose-600 to-red-500' : 'from-teal-500 to-emerald-500',
      glowColor: 'shadow-teal-500/30',
      badgeColor: airFlowValue < airMin ? 'bg-rose-950 text-rose-300 border-rose-800' : 'bg-teal-950 text-teal-300 border-teal-800',
      textColor: airFlowValue < airMin ? 'text-rose-400' : 'text-teal-400',
      status: airFlowValue < airMin ? 'Bajo' : 'Óptimo',
      norm: `DS 132: Mínimo ${airMin} m/s`
    },
    {
      id: 'noise',
      name: 'Ruido Acústico',
      shortName: 'Ruido',
      unit: 'dB',
      value: Number(noiseValue.toFixed(0)),
      safeMax: noiseSafe,
      criticalMax: noiseCrit,
      scaleMax: Math.max(110, noiseCrit + 15),
      icon: <Volume2 className="w-4 h-4 text-rose-400" />,
      gradient: noiseValue > noiseSafe ? 'from-rose-600 to-red-600' : 'from-rose-500 to-amber-500',
      glowColor: 'shadow-rose-500/30',
      badgeColor: noiseValue > noiseSafe ? 'bg-rose-950 text-rose-300 border-rose-800' : 'bg-slate-900 text-slate-300 border-slate-700',
      textColor: noiseValue > noiseSafe ? 'text-rose-400' : 'text-slate-300',
      status: noiseValue > noiseSafe ? 'Elevado' : 'Aceptable',
      norm: `DS 132: LPP ≤ ${noiseSafe} dB(A)`
    },
    {
      id: 'o2',
      name: 'Oxígeno (O2)',
      shortName: 'Oxígeno',
      unit: '%',
      value: Number(o2Value.toFixed(1)),
      safeMax: 21.0,
      criticalMax: o2Min,
      scaleMax: 25.0,
      icon: <Activity className="w-4 h-4 text-emerald-400" />,
      gradient: o2Value < o2Min ? 'from-rose-600 to-red-600' : 'from-emerald-400 to-teal-500',
      glowColor: 'shadow-emerald-500/30',
      badgeColor: o2Value < o2Min ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse' : 'bg-emerald-950 text-emerald-300 border-emerald-800',
      textColor: o2Value < o2Min ? 'text-rose-400' : 'text-emerald-400',
      status: o2Value < o2Min ? 'Deficiente' : 'Normal',
      norm: `DS 132: Mínimo ${o2Min}% O2`
    }
  ];

  // Real timeline readings sourced exclusively from /historial_telemetria in RTDB
  const recentHistory = telemetryHistory.slice(-6);
  const timelineReadings =
    recentHistory.length > 0
      ? recentHistory.map((pt, idx) => ({
          hour:
            idx === recentHistory.length - 1
              ? 'Última'
              : new Date(pt.timestamp).toLocaleTimeString('es-CL', {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
          temp: typeof pt.temperatura === 'number' ? pt.temperatura : tempValue,
          hum: typeof pt.humedad === 'number' ? pt.humedad : humValue,
          co: typeof pt.co === 'number' ? pt.co : coValue,
          co2: co2Value,
          pm25: typeof pt.pm25 === 'number' ? pt.pm25 : pm25Value,
          ch4: ch4Value,
          airFlow: airFlowValue,
          noise: noiseValue,
          o2: o2Value,
        }))
      : [
          {
            hour: 'Actual (en vivo)',
            temp: tempValue,
            hum: humValue,
            co: coValue,
            co2: co2Value,
            pm25: pm25Value,
            ch4: ch4Value,
            airFlow: airFlowValue,
            noise: noiseValue,
            o2: o2Value,
          },
        ];

  return (
    <div className="space-y-6">
      
      {/* ==============================================================
          1. WELCOME MESSAGE & USER ROLE BANNER (Inspirado en el diseño)
         ============================================================== */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 p-5 sm:p-6 shadow-xl">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Welcome User info */}
          <div className="flex items-center gap-3.5">
            <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center font-bold text-lg sm:text-xl shadow-lg shrink-0 ${userRoleInfo.avatarBg}`}>
              {currentUser?.name?.charAt(0) || 'M'}
            </div>
            
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-1.5">
                  Bienvenido, {currentUser?.name || 'Usuario Autenticado'}
                </h2>
                
                {/* User Role highlighted badge */}
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border shadow-sm ${userRoleInfo.bg}`}>
                  {userRoleInfo.icon}
                  <span>{userRoleInfo.typeText}</span>
                </span>
              </div>
              
              <p className="mt-1 text-xs sm:text-sm text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-1">
                <span>{userRoleInfo.label}</span>
                <span>•</span>
                <span className="text-slate-300 font-medium">{currentUser?.shift || 'Turno Continuo 7x7'}</span>
                <span>•</span>
                <span className="text-cyan-400 font-mono">{siteName || currentDevice?.sectorName || 'Faena Minera Central'}</span>
              </p>
            </div>
          </div>

          {/* Quick Actions: Role change button */}
          <div className="flex flex-wrap items-center gap-2.5 self-start md:self-center">
            {onChangeUserModal && (
              <button
                onClick={onChangeUserModal}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-cyan-500/50 transition-all flex items-center gap-2 shadow-sm"
              >
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                <span>Cambiar de Usuario</span>
              </button>
            )}
          </div>
        </div>

        {/* 4 Quick Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-5 border-t border-slate-800/80">
          
          {/* Card 1: Total Users */}
          <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800/80 hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Total Usuarios</span>
              <div className="w-7 h-7 rounded-lg bg-blue-950/60 border border-blue-800/60 flex items-center justify-center text-blue-400">
                <Users className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="mt-2 text-2xl font-black text-white tabular-nums">
              {totalUsersCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5 truncate">
              <span className="text-purple-400 font-semibold">{superadminCount} Super</span> • 
              <span className="text-cyan-400 font-semibold">{adminCount} Adm</span> • 
              <span className="text-amber-400 font-semibold">{operadorCount} Op</span>
            </div>
          </div>

          {/* Card 2: Sensores IoT Online */}
          <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800/80 hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Sensores IoT Online</span>
              <div className="w-7 h-7 rounded-lg bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                <Cpu className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="mt-2 text-2xl font-black text-emerald-400 tabular-nums">
              {onlineDevicesCount} <span className="text-xs font-normal text-slate-400">/ {devices.length}</span>
            </div>
            <div className="text-[11px] text-emerald-300 mt-0.5 flex items-center gap-1 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Transmisión en vivo RTDB</span>
            </div>
          </div>

          {/* Card 3: Dispositivo Seleccionado */}
          <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800/80 hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Dispositivo Activo</span>
              <div className="w-7 h-7 rounded-lg bg-cyan-950/60 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
                <Radio className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="mt-2 text-sm sm:text-base font-bold text-white truncate" title={currentDevice?.name}>
              {currentDevice?.name || 'ESP32 Gateway'}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5 font-mono truncate">
              {currentDevice?.code || currentDevice?.id} · Batería: {batteryPct}%
            </div>
          </div>

          {/* Card 4: Alertas Activas */}
          <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800/80 hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Alertas de Faena</span>
              <div className={`w-7 h-7 rounded-lg ${activeAlertCount > 0 ? 'bg-amber-950/80 border border-amber-800 text-amber-400' : 'bg-slate-900 border border-slate-800 text-slate-400'} flex items-center justify-center`}>
                <AlertTriangle className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className={`mt-2 text-2xl font-black tabular-nums ${activeAlertCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
              {activeAlertCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {activeAlertCount === 0 ? 'Límites seguros bajo DS 132' : 'Verificar ventilación en galería'}
            </div>
          </div>

        </div>
      </div>

      {/* ==============================================================
          2. TWO-COLUMN INTERACTIVE SECTION:
             - LEFT: SENSOR LEVELS BAR CHART WITH ALL SENSORS & DEVICE SELECTOR
             - RIGHT: SCROLLABLE SYSTEM USERS LIST
         ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* ============================================================
            COL 1: SENSOR LEVELS BAR CHART (7 / 12 cols)
           ============================================================ */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col justify-between">
          
          <div>
            {/* Header with Title and Mode Switcher */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800/80">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                    Gráfico de Barras: Sensores IoT
                    <span className="text-xs font-mono font-normal text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                      {currentDevice?.code || currentDevice?.id}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Mediciones de todos los sensores (Temperatura, Humedad, CO, CO2, PM2.5, Metano, Flujo, Ruido, O2)
                  </p>
                </div>
              </div>

              {/* 3 View mode toggles */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 self-start sm:self-center shrink-0">
                <button
                  onClick={() => setChartViewMode('all_bars')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    chartViewMode === 'all_bars' 
                      ? 'bg-cyan-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Gráfico de barras vertical con todos los sensores medidos"
                >
                  Barras de Sensores
                </button>
                <button
                  onClick={() => setChartViewMode('levels')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    chartViewMode === 'levels' 
                      ? 'bg-cyan-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Indicadores horizontales con límites normativos DS 132"
                >
                  Niveles DS 132
                </button>
                <button
                  onClick={() => setChartViewMode('timeline')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    chartViewMode === 'timeline' 
                      ? 'bg-cyan-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Evolución temporal por turnos"
                >
                  Tendencia Temporal
                </button>
              </div>
            </div>

            {/* DEVICE SELECTOR: Direct buttons + dropdown for all devices */}
            <div className="mt-4 pt-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  Cambiar Dispositivo Sensor:
                </span>
                <span className="text-[11px] text-slate-400">
                  Ubicación: <strong className="text-slate-200">{currentDevice?.sectorName}</strong>
                </span>
              </div>

              {/* Quick Select Buttons for main Gateways / Detectors */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                {devices.slice(0, 4).map((dev) => {
                  const isSelected = dev.id === currentDevice?.id;
                  const isDevOnline = dev.status !== 'desconectado';
                  return (
                    <button
                      key={dev.id}
                      onClick={() => onSelectDevice(dev.id)}
                      className={`flex flex-col text-left p-2.5 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-cyan-950/80 border-cyan-500 text-white shadow-md shadow-cyan-950/50 ring-1 ring-cyan-400/50'
                          : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="text-xs font-bold truncate">{dev.code || dev.id.slice(-6)}</span>
                        <span className={`w-2 h-2 rounded-full ${isDevOnline ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                      </div>
                      <span className="text-[10px] text-slate-400 truncate mt-0.5">{dev.name.split(' ')[0]} {dev.name.split(' ')[1] || ''}</span>
                    </button>
                  );
                })}
              </div>

              {/* Comprehensive Dropdown for ALL devices */}
              {devices.length > 4 && (
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-xs text-slate-400 shrink-0">O seleccionar otro equipo:</span>
                  <select
                    value={currentDevice?.id}
                    onChange={(e) => onSelectDevice(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  >
                    {devices.map((dev) => (
                      <option key={dev.id} value={dev.id}>
                        {dev.code} - {dev.name} ({dev.sectorName})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* ========================================================
                CHART MODE 1: VERTICAL SENSOR BARS CHART (TODOS LOS SENSORES)
                (Temperatura, Humedad, CO, CO2, PM2.5, Metano, Flujo, Ruido, O2)
               ======================================================== */}
            {chartViewMode === 'all_bars' && (
              <div className="mt-3 bg-slate-950/80 border border-slate-800/90 rounded-2xl p-4 sm:p-5">
                
                <div className="flex items-center justify-between text-xs text-slate-400 mb-4 pb-2 border-b border-slate-800">
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    Comparativa de Sensores en Vivo ({allSensorBars.length} Variables)
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Nodo: <strong className="text-cyan-300">{currentDevice?.code || currentDevice?.id}</strong>
                  </span>
                </div>

                {/* THE 9 VERTICAL SENSOR BARS */}
                <div className="grid grid-cols-3 sm:grid-cols-9 gap-2 sm:gap-2.5 items-end pt-6 pb-2 min-h-[260px]">
                  {allSensorBars.map((sensor) => {
                    // Normalize bar height percentage for clear visual comparison
                    const pct = Math.min(100, Math.max(14, (sensor.value / sensor.scaleMax) * 100));
                    const isHovered = hoveredSensorId === sensor.id;
                    const isAlert = sensor.value > sensor.safeMax;

                    return (
                      <div 
                        key={sensor.id} 
                        className="flex flex-col items-center justify-end h-full group relative cursor-pointer"
                        onMouseEnter={() => setHoveredSensorId(sensor.id)}
                        onMouseLeave={() => setHoveredSensorId(null)}
                      >
                        {/* Hover Tooltip */}
                        {isHovered && (
                          <div className="absolute -top-12 z-20 bg-slate-900 border border-cyan-500/80 text-white text-[10px] py-1 px-2.5 rounded-lg shadow-xl whitespace-nowrap pointer-events-none">
                            <p className="font-bold text-cyan-300">{sensor.name}</p>
                            <p className="text-slate-300">{sensor.value} {sensor.unit} · {sensor.norm}</p>
                          </div>
                        )}

                        {/* Numerical Value Badge on Top of Bar */}
                        <div className="mb-2 text-center">
                          <span className={`text-[11px] sm:text-xs font-mono font-black tabular-nums transition-transform duration-200 block ${sensor.textColor} ${isHovered ? 'scale-110 font-extrabold' : ''}`}>
                            {sensor.value}
                          </span>
                          <span className="text-[9px] text-slate-400 block -mt-0.5 font-mono">
                            {sensor.unit}
                          </span>
                        </div>

                        {/* Bar Pillar Track */}
                        <div className="w-full max-w-[38px] bg-slate-900/90 rounded-t-xl h-36 flex items-end p-1 border border-slate-800 group-hover:border-slate-700 transition-colors relative overflow-hidden">
                          {/* Safe limit line indicator */}
                          <div 
                            className="absolute left-0 right-0 h-0.5 bg-slate-700/60 z-10 pointer-events-none"
                            style={{ bottom: `${Math.min(95, (sensor.safeMax / sensor.scaleMax) * 100)}%` }}
                            title={`Límite seguro: ${sensor.safeMax} ${sensor.unit}`}
                          />

                          {/* Colored Vertical Bar */}
                          <div 
                            className={`w-full rounded-t-lg bg-gradient-to-t ${sensor.gradient} shadow-lg ${sensor.glowColor} transition-all duration-500 group-hover:brightness-125`}
                            style={{ height: `${pct}%` }}
                          />
                        </div>

                        {/* Sensor Bottom Label & Status Badge */}
                        <div className="mt-2 text-center w-full flex flex-col items-center">
                          <div className="flex items-center justify-center mb-0.5">
                            {sensor.icon}
                          </div>
                          <span className="text-[10px] sm:text-[11px] font-bold text-slate-300 truncate max-w-full">
                            {sensor.shortName}
                          </span>
                          
                          {/* Mini Status Pill */}
                          <span className={`mt-1 text-[9px] font-bold px-1.5 py-0.2 rounded-full border ${sensor.badgeColor}`}>
                            {sensor.status}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Subtitle Guide */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-2">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-400" /> Seguro</span>
                    <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-400" /> Atención</span>
                    <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" /> Crítico</span>
                  </div>
                  <span className="font-mono text-[10px] text-slate-500">
                    Línea tenue = Límite normativo seguro DS 132
                  </span>
                </div>

              </div>
            )}

            {/* ========================================================
                CHART MODE 2: HORIZONTAL LEVELS & DS 132 LIMIT GAUGES
               ======================================================== */}
            {chartViewMode === 'levels' && (
              <div className="space-y-3 mt-3">
                {allSensorBars.map((metric) => {
                  const pct = Math.min(100, Math.max(5, (metric.value / metric.scaleMax) * 100));
                  const isAboveSafe = metric.value > metric.safeMax;

                  return (
                    <div 
                      key={metric.id}
                      className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <div className="flex items-center gap-2">
                          {metric.icon}
                          <span className="font-semibold text-slate-200">{metric.name}</span>
                          <span className="text-[10px] text-slate-400 hidden sm:inline">({metric.norm})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${metric.badgeColor}`}>
                            {metric.status}
                          </span>
                          <span className={`font-mono font-bold text-sm ${metric.textColor}`}>
                            {metric.value} <span className="text-xs text-slate-400 font-normal">{metric.unit}</span>
                          </span>
                        </div>
                      </div>

                      {/* Visual gauge bar */}
                      <div className="relative w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                        <div 
                          className="absolute top-0 bottom-0 w-0.5 bg-slate-600 z-10"
                          style={{ left: `${(metric.safeMax / metric.scaleMax) * 100}%` }}
                          title={`Límite seguro: ${metric.safeMax} ${metric.unit}`}
                        />
                        <div 
                          className={`h-full rounded-full transition-all duration-500 bg-gradient-to-r ${metric.gradient}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* ========================================================
                CHART MODE 3: TIMELINE EVOLUTION WITH ALL SENSOR GROUPS
               ======================================================== */}
            {chartViewMode === 'timeline' && (
              <div className="mt-4 bg-slate-950/80 border border-slate-800 rounded-2xl p-4 sm:p-5">
                
                {/* Metric group switcher */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
                  <span className="font-semibold text-xs sm:text-sm text-slate-200">
                    Evolución Temporal en el Turno
                  </span>

                  <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
                    <button
                      onClick={() => setTimelineGroup('gases')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                        timelineGroup === 'gases' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      CO & PM2.5
                    </button>
                    <button
                      onClick={() => setTimelineGroup('clima')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                        timelineGroup === 'clima' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      Temp & Humedad
                    </button>
                    <button
                      onClick={() => setTimelineGroup('seguridad')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                        timelineGroup === 'seguridad' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      CO2, Metano & Ruido
                    </button>
                    <button
                      onClick={() => setTimelineGroup('todos')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                        timelineGroup === 'todos' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      Todos
                    </button>
                  </div>
                </div>

                {/* Legend */}
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mb-4 px-1">
                  {(timelineGroup === 'gases' || timelineGroup === 'todos') && (
                    <>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-orange-500" /> Monóxido CO (ppm)</span>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-cyan-400" /> Polvo PM2.5 (µg/m³)</span>
                    </>
                  )}
                  {(timelineGroup === 'clima' || timelineGroup === 'todos') && (
                    <>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-400" /> Temp (°C)</span>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-indigo-400" /> Humedad (%)</span>
                    </>
                  )}
                  {(timelineGroup === 'seguridad' || timelineGroup === 'todos') && (
                    <>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> CO2 (ppm/10)</span>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-400" /> Metano CH4 (%)</span>
                      <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-rose-400" /> Ruido (dB)</span>
                    </>
                  )}
                </div>

                {/* Honest Telemetry History Notice */}
                {recentHistory.length < 2 && (
                  <div className="mb-3 px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] text-slate-400">
                    Muestras reales en RTDB: <strong className="text-cyan-300">{recentHistory.length}</strong>. Mostrando lectura real sin interpolación simulada; la serie crecerá conforme el nodo transmita nuevos paquetes.
                  </div>
                )}

                {/* Multi-Bar Timeline Chart */}
                <div className="h-44 w-full flex items-end justify-between gap-2 pt-2 px-1">
                  {timelineReadings.map((reading, index) => {
                    return (
                      <div key={index} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                        <div className="w-full flex items-end justify-center gap-1 h-32 px-0.5">
                          {/* CO Bar */}
                          {(timelineGroup === 'gases' || timelineGroup === 'todos') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-orange-600 to-orange-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.co / Math.max(50, coSafe)) * 100))}%` }}
                              title={`CO: ${reading.co.toFixed(1)} ${isRawCO ? 'ADC' : 'ppm'}`}
                            />
                          )}

                          {/* PM2.5 Bar */}
                          {(timelineGroup === 'gases' || timelineGroup === 'todos') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.pm25 / Math.max(100, pm25Safe)) * 100))}%` }}
                              title={`PM2.5: ${reading.pm25.toFixed(1)} ${isRawPM25 ? 'ADC' : 'µg/m³'}`}
                            />
                          )}

                          {/* Temp Bar */}
                          {(timelineGroup === 'clima' || timelineGroup === 'todos') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.temp / 35) * 100))}%` }}
                              title={`Temp: ${reading.temp.toFixed(1)} °C`}
                            />
                          )}

                          {/* Humedad Bar */}
                          {(timelineGroup === 'clima' || timelineGroup === 'todos') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-indigo-600 to-indigo-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.hum / 100) * 100))}%` }}
                              title={`Humedad: ${reading.hum.toFixed(0)} %`}
                            />
                          )}

                          {/* CO2 Bar */}
                          {(timelineGroup === 'seguridad' || timelineGroup === 'todos') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-emerald-600 to-emerald-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.co2 / 1500) * 100))}%` }}
                              title={`CO2: ${reading.co2} ppm`}
                            />
                          )}

                          {/* Metano CH4 Bar */}
                          {(timelineGroup === 'seguridad' || timelineGroup === 'todos') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-purple-600 to-purple-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.ch4 / 2) * 100))}%` }}
                              title={`CH4: ${reading.ch4.toFixed(1)} %`}
                            />
                          )}

                          {/* Ruido Bar */}
                          {(timelineGroup === 'seguridad') && (
                            <div 
                              className="flex-1 max-w-[14px] bg-gradient-to-t from-rose-600 to-rose-400 rounded-t-sm transition-all duration-300 group-hover:brightness-125"
                              style={{ height: `${Math.min(100, Math.max(12, (reading.noise / 100) * 100))}%` }}
                              title={`Ruido: ${reading.noise} dB`}
                            />
                          )}
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 text-center">{reading.hour}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Footer of device card */}
          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Battery className="w-3.5 h-3.5 text-emerald-400" />
              <span>Batería: <strong className="text-slate-200">{batteryPct}%</strong></span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[11px]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Transmisión activa · {currentDevice?.signalStrength || 'Óptima'}</span>
            </div>
          </div>
        </div>

        {/* ============================================================
            COL 2: SCROLLABLE SYSTEM USERS LIST BOX (5 / 12 cols)
           ============================================================ */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col">
          
          {/* Header of Users Box */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-950 text-purple-400 border border-purple-800/80">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Usuarios del Sistema
                  <span className="text-xs font-semibold bg-purple-950/80 text-purple-300 px-2 py-0.5 rounded-full border border-purple-800/60">
                    {filteredUsers.length}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">Personal autorizado y roles en faena</p>
              </div>
            </div>
          </div>

          {/* Search Input & Role Filter Tabs */}
          <div className="my-3 space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar por nombre, RUT o cargo..."
                value={userSearchTerm}
                onChange={(e) => setUserSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>

            {/* Quick role pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
              {(['todos', 'superadmin', 'admin', 'operador'] as const).map((role) => {
                const isActive = selectedRoleFilter === role;
                return (
                  <button
                    key={role}
                    onClick={() => setSelectedRoleFilter(role)}
                    className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors ${
                      isActive
                        ? 'bg-cyan-600 text-white shadow-sm font-semibold'
                        : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    {role === 'todos' ? 'Todos' : role === 'superadmin' ? 'Superadmin' : role === 'admin' ? 'Admin' : 'Operadores'}
                  </button>
                );
              })}
            </div>
          </div>

          {/* SCROLLABLE USERS LIST CONTAINER (With prominent vertical scrollbar) */}
          <div className="flex-1 overflow-y-auto max-h-[380px] pr-1.5 space-y-2.5 custom-scrollbar">
            {filteredUsers.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400 bg-slate-950/40 rounded-xl border border-slate-800/60">
                No se encontraron usuarios con ese criterio.
              </div>
            ) : (
              filteredUsers.map((user) => {
                const isCurrent = currentUser?.id === user.id || currentUser?.email.toLowerCase() === user.email.toLowerCase();
                const roleMeta = getRoleDetails(user.role);

                return (
                  <div
                    key={user.id}
                    onClick={() => onSelectUser?.(user)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isCurrent
                        ? 'bg-slate-950/90 border-cyan-500/70 shadow-md shadow-cyan-950/30 ring-1 ring-cyan-500/30'
                        : 'bg-slate-950/50 border-slate-800/80 hover:bg-slate-950 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      {/* Avatar and Main Info */}
                      <div className="flex items-start gap-2.5 min-w-0">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 shadow-sm ${roleMeta.avatarBg}`}>
                          {user.name.charAt(0)}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-xs sm:text-sm font-bold text-slate-100 truncate">
                              {user.name}
                            </h4>
                            {isCurrent && (
                              <span className="text-[9px] bg-cyan-950 text-cyan-300 border border-cyan-700 px-1.5 py-0.2 rounded font-semibold">
                                TÚ
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-slate-400 truncate mt-0.5">
                            {user.email}
                          </p>

                          {user.rut && (
                            <p className="text-[10px] font-mono text-slate-500">
                              RUT: {user.rut}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Role Badge on the right */}
                      <div className="shrink-0 text-right">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${roleMeta.badgeBg}`}>
                          {roleMeta.icon}
                          <span>{roleMeta.typeText}</span>
                        </span>
                        
                        <div className="flex items-center justify-end gap-1 mt-1.5 text-[10px] text-slate-400">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span>{user.status === 'activo' ? 'En Línea' : 'Inactivo'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Secondary details: Shift or Sector */}
                    <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-400">
                      <span className="truncate">
                        {user.shift || user.assignedSector || 'Turno General de Operaciones'}
                      </span>
                      <span className="text-cyan-400/80 font-medium shrink-0 flex items-center gap-0.5">
                        <span>Ver perfil</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer note indicating scrollability */}
          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
            <span>Usa la barra para desplazar el listado</span>
            <span className="text-cyan-400 font-medium">Desplazamiento vertical activo</span>
          </div>

        </div>

      </div>

    </div>
  );
};

